Modificações:
Os arquivos 01-playback.cpp e 01-playback.hpp foram adicionados.
uma nova função espera foi criada na main
a main foi modificada, logo após a função choque, o programa chama funções para realizar o blip
uma função para parar o player de som foi adicionada ao final do programa
