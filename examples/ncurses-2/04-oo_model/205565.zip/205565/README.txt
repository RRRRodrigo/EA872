Alterações feitas:
Uma nova função foi adicionada no objeto Física
A física foi alterada para simular um modelo massa-mola-amortecedor
As dimensões máximas da tela foram alteradas
Um segundo choque foi adicionado e pode ser usado pressionando 's'
A main foi modificada com a função acima
O valor da velocidade em choque foi alterado

