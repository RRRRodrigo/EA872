Alterações nos arquivos:
Os valores dos corpos e o tamanho da tela na main foram alterados.
O comportamento da física foi alterado para ser similar ao modelo massa-mola-amortecimento.
Na atualização da Tela, o programa apaga todas as posições, e antes de desenhar o corpo na tela, ele zera a posição do cursor. O programa também começa a desenhar a posição a partir da posição 20.

